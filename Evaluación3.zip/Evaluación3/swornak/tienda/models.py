from django.db import models 

# Create your models here.

class Marca(models.Model):
    modelo=models.CharField(max_length=100)

    def __str__(self):
        return self.modelo


class Producto(models.Model):
    modelo = models.ForeignKey(Marca, on_delete=models.PROTECT)
    descripcion = models.CharField(max_length=50)
    precio = models.IntegerField()
    imagen = models.ImageField(upload_to="productos", null=True)
    size = models.IntegerField()  
    
    def __str__(self):
        return f"{self.modelo.modelo} - {self.descripcion}"

    

